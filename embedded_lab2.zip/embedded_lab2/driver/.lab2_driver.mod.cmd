cmd_/home/locvhm/embedded_lab2/driver/lab2_driver.mod := { echo  /home/locvhm/embedded_lab2/driver/lab2_driver.o;  echo; } > /home/locvhm/embedded_lab2/driver/lab2_driver.mod
