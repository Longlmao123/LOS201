cmd_/home/locvhm/embedded_lab2/driver/modules.order := {   echo /home/locvhm/embedded_lab2/driver/lab2_driver.ko; :; } | awk '!x[$$0]++' - > /home/locvhm/embedded_lab2/driver/modules.order
