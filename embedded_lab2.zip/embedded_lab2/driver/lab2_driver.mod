/home/locvhm/embedded_lab2/driver/lab2_driver.o

